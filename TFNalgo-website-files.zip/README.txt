# TFNalgo website

## Files
- `index.html` — public sales page
- `success.html` — post-checkout Telegram activation instructions
- `tfnalgo-chart.jpg` — chart crop from your supplied TFN poster
- `tfnalgo-poster.jpg` — original poster image

## Publish with GitHub Pages
1. Create a new **public** GitHub repository (for example `tfnalgo-site`).
2. Upload all four files to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub will show your public website address after it deploys.

## Important: configure Stripe's post-payment redirect
In your Stripe Dashboard, open the payment link and set its after-payment redirect URL to the published URL for `success.html` (for example `https://YOUR-USERNAME.github.io/tfnalgo-site/success.html`).

This static GitHub Pages success page is an instruction page, not proof of payment. Anyone who knows its URL could open it directly. Check the payment in Stripe before granting indicator access. For stronger automatic verification, use a payment backend/webhook rather than relying only on a redirect.

## Before publishing
- Confirm the Stripe payment link charges the intended introductory price (£25) and that you have a plan for changing the offer to £50 after the first 25 members.
- Confirm that the indicator and future-indicator access terms match what you intend to offer.
- The page includes a general trading-risk disclaimer. It does not constitute legal or regulatory advice.
